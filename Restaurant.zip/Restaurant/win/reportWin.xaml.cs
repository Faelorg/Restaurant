﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;

namespace Restaurant.win
{
    /// <summary>
    /// Логика взаимодействия для reportWin.xaml
    /// </summary>
    public partial class reportWin : Page
    {
        entities _context = new entities();
        public reportWin()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Global.frm.GoBack();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ReportWord();
        }

        public void ReportWord()
        {
            Word.Application app = new Word.Application();

            var doc = app.Documents.Add();

            var par1 = doc.Paragraphs.Add();
            Word.Range range = par1.Range;
            if (cmbView.SelectedIndex == 0)
            {
                var table = range.Tables.Add(range, 6,2);
                table.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;
                table.Borders.InsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;
                
                var sells = _context.Sell1.ToList().FindAll(x => x.date.Month == DateTime.Now.Month - 1).ToList();
                table.Title = "Лучший сотрудник месяца";

                table.ApplyStyleHeadingRows = true;
                table.Cell(2, 1).Range.Text = "Фамилия";
                table.Cell(3, 1).Range.Text = "Имя";
                table.Cell(4, 1).Range.Text = "Отчество";
                table.Cell(5, 1).Range.Text = "Телефон";
                table.Cell(6, 1).Range.Text = "Количество продаж";

                table.Cell(2, 2).Range.Text = EmployeeForMonth().Surname;
                table.Cell(3, 2).Range.Text = EmployeeForMonth().Firstname;
                table.Cell(4, 2).Range.Text = EmployeeForMonth().Patronomics;
                table.Cell(5, 2).Range.Text = EmployeeForMonth().Phone;
                table.Cell(6, 2).Range.Text = ""+sells.FindAll(x=>x.User1 == EmployeeForMonth()).Count;
                
            }
            app.Visible = true;
        }

        public void ReportExcel()
        {
            
        }

        public List<Sell1> SellForMonth()
        {
            var sells = _context.Sell1.ToList().FindAll(x => x.date.Month == DateTime.Now.Month - 1);
            return sells;
        }

        public Product1 ProductForMonth() {
            var sells = _context.Sell1.ToList().FindAll(x => x.date.Month == DateTime.Now.Month - 1);

            var ps = new List<ProductSell>();
            sells.ForEach(x =>
            {
                x.ProductSell.ToList().ForEach(p=>
                {
                    ps.Add(p);
                });
            });

            var products = new List<Product1>();
            return ps.Find(x => x.count >= ps.Max(p => p.count)).Product1;
        }

        private User1 EmployeeForMonth()
        {
            var sells = _context.Sell1.ToList().FindAll(x=>x.date.Month == DateTime.Now.Month-1);

            var most = sells.GroupBy(x => x.User1).OrderByDescending(x => x.Count()).First();

            return most.Key;
        }
    }
}
