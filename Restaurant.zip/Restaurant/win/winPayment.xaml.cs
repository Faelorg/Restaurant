﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Restaurant.pages;

namespace Restaurant.win
{
    /// <summary>
    /// Логика взаимодействия для winPayment.xaml
    /// </summary>
    public partial class winPayment : Window
    {
        entities _context = entities.GetContext();
        List<SaleProduct> saleProducts;
        int count = 0;
        public winPayment(List<SaleProduct> product)
        {
            InitializeComponent();
            txbDiscount.Text = 0 + "";
            txbDiscount1.Text = 0 + "";
            this.saleProducts = product;
            Update();
            int count = 0;
            saleProducts.ForEach(x =>
            {
                count += x.Count;
            });
            this.count = count;
            txbTotalItems.Text = count + "";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {

            Sell1 s = new Sell1()
            {
                Discount1 = _context.Discount1.ToList().Find(d => d.Phone == txbPhoneClient.Text),
                date = dptTime.SelectedDate.Value,
                User1 = Global.user,
                SellId = 0,
            };
            saleProducts.ForEach(x => {


                ProductSell ps = new ProductSell()
                {
                    count = x.Count,
                    ProductId = x.id,
                    Product1 = _context.Product1.Find(x.id),
                };

                s.ProductSell.Add(ps);
                ps.SellId = s.id;
                ps.Sell1 = s;


                _context.ProductSell.Add(ps);
            });
            _context.Sell1.Add(s);

            _context.SaveChanges();

            this.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Update()
        {
            var sum = 0d;
            saleProducts.ForEach(x =>
            {
                sum += x.Price * x.Count;
            });
            txbTotal.Text = sum + "";

            txbTotalPay.Text = (sum - (sum * int.Parse(txbDiscount.Text) / 100)) + "";
        }

        private void txbPhoneClient_TextChanged(object sender, TextChangedEventArgs e)
        {
            var client = _context.Discount1.ToList().Find(x => x.Phone == txbPhoneClient.Text);
            if (client != null)
            {
                txbDiscount.Text = client.Percent + "";
                txbDiscount1.Text = client.Percent + "";
            }
            else
            {
                txbDiscount.Text = 0+"";
                txbDiscount1.Text = 0 + "";
            }
            Update();
        }
    }
}
