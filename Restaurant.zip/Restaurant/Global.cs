﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Restaurant
{
    static class Global
    {
        public static Frame frm { get; set; }
        public static User1 user { get; set; }
    }
}
